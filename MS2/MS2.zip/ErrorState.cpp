#include <iostream>
#include <cstring>
#include "ErrorState.h"

namespace AMA {	

	
	ErrorState::ErrorState(const char* errorMessage ) {

		if (errorMessage == nullptr) {
			eMessage = nullptr;
		}
		else {
			eMessage = new char[strlen(errorMessage) + 1];
			strcpy(eMessage, errorMessage);
			eMessage[strlen(errorMessage)] = '\0';

		}

	}
	


	ErrorState::~ErrorState() {

		delete [] eMessage;
		eMessage = nullptr;

	}



	void ErrorState::clear() {
		delete[] this->eMessage;
		eMessage = nullptr;
		

	}
	bool ErrorState::isClear() const {
		
		bool clear = false;
		if (eMessage == nullptr) {
			clear = true;
		}
		return clear;
		
	}
	void ErrorState::message(const char* str) {

		delete[] eMessage;
		eMessage = new char[strlen(str)+1];
		strcpy(eMessage, str);
		eMessage[strlen(str)] = '\0';
		
	}
	const char* ErrorState::message()const {
		
		return eMessage;

	}
	ostream & operator<< (std::ostream & os, ErrorState& a) {
		
		if (a.isClear() == false) {
			os << a.message();
		}

		return os;

	}







}